# React Fitness Application
# Available Scripts
In the project directory, you can run:

## npm start
Runs the app in the development mode.
Open http://localhost:3000 to view it in your browser.

The page will reload when you make changes.
You may also see any lint errors in the console.

Run the Application
To run the application, clone the repository:
Navigate to the project directory:
## cd Fitness-app

Install the required dependencies after going to frontend 
## npm install

Configure the application by updating the necessary environment variables. You can find the configuration file in config/config.env.
Start the application on both folder:
## npm start

Access the application by visiting http://localhost:3000 in your web browser.
or if you want to direct link to project
### https://62e03740c38d58055115b171--lighthearted-peony-49810f.netlify.app/#exercises
